start "" "C:\BBA\BBA.exe" --CC1 "C:\BBA\GIB1.bbsa" --CC2 "C:\BBA\GIB2.bbsa" --TM_MEMBER 2 --SERVER 127.0.0.1 --PORT 2000 --PD 1
